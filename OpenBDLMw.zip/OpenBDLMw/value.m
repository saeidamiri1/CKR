dat=load('DATA_BDLM_EXAMPLE4.mat'); 
data.values(:,1)=dat.values;
data.values(:,2)=dat.values;
data.timestamps=dat.timestamps;
data.labels={'TemperatureTimeseries','PressureTimeseries'};
save('DATA_EXERCISE1.mat','-struct','data');
exer = load('DATA_EXERCISE1.mat');