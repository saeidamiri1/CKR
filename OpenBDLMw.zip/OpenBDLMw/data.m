dat=load('DATA_BDLM_EXAMPLE4.mat'); 
data.values=dat.values;
data.timestamps=dat.timestamps;
data.labels={'TemperatureTimeseries'};