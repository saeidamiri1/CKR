function [K_norm]=Kernel_componentb(t)
%% Kernel parameters
l=.5;
p=365.25;

%% Periodic Kernel
K=@(x,cp) exp(-2/l.^2*sin(pi*(x-cp)./p).^2);

%% Control points
nb_p=11
timestamp_ref=735965
x_cp=linspace(timestamp_ref,timestamp_ref+p,nb_p+1);
x_cp(end)=[];

%% Kernel regression
X_cp=repmat(x_cp,[length(t),1]);
X=repmat(t,[1,length(x_cp)]);

K_raw=K(X,X_cp); %raw kernel evaluation
K_norm=K_raw./repmat(sum(K_raw,2)+10^-8,[1,length(x_cp)]); %normalized kernel coefficients
K_norm = K_norm - mean(K_norm); % force the mean to be zero
%--------------------END CODE ---------------------- 
end